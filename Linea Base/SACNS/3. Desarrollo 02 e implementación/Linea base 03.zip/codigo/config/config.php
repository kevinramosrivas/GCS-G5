<?php
    $servidor = 'localhost';
    $usuario = 'root';
    $password = '';
    $basedatos = 'sacns_bd';
?>